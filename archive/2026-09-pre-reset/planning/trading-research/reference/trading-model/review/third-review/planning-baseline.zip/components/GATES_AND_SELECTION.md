# Mixtures, calibration and sequential selection

[Common contracts](COMMON_CONTRACTS.md) apply. These components preserve granular specialists while making the current decision coherent. They combine **compatible forecasts**, compare complete opportunity sets and expose disagreement. Risk constraints in P remain independent and cannot be learned away.

## G01 — Target-specific Context and path mixtures

1. **Purpose/sources.** Implement serious granular MoE without averaging unrelated outputs; user MoE requirement, CRL-17, TECH-07 and retained prior ensemble ideas.
2. **Inputs.** OOF/live `Forecast` objects from applicable C, O22 and X experts sharing exact receiver asset, decision cut, observation process, target ID/horizon. Context/coverage/age features are as-of; update at decision cadence.
3. **Definition.** For each target, mix full expert distributions with nonnegative normalized weights; compare uniform, fixed validation-weighted and regularized softmax `w_e=softmax(theta_e·z)` with missing masks. Separate heads for global PATH, specific object PATH and transition labels; incompatible targets are not mixed. Mixture quantiles derive from the mixture CDF/samples, not naive averaging of quantiles. Gate can specialize by session, width/path state, coverage and residual diversity.
4. **Output.** Calibrated mixture distribution, weights, each expert prediction/version, between/within-expert dispersion, effective expert count and missing-pattern applicability.
5. **Dependencies.** F11/C20, frozen G03.apply calibrators and G09.MASK critical validity. Current G09.SELECT/value uncertainty is downstream and cannot alter these same-cut mixture weights. L formation/roles and G04–08 consume the result; training uses time-honest upstream errors.
6. **Comparisons.** Best simple single model, uniform/static blend, linear gate, shallow tree/neural gate. Compare specialist diversity by feature family and mechanism, not random neural seeds alone.
7. **Training.** Nested chronological OOF pipeline, separate gate/calibration validation; natural target prevalence and all eligible decisions. Limit gate complexity/support per regime; expert dropouts mimic actual missingness.
8. **Tests.** Target/horizon mismatch, all experts absent, one stale expert, conflicting calibrated forecasts, correlated duplicate experts, in-sample upstream injection, gate collapse and reordered experts.
9. **Acceptance.** Proper-score/calibration gain over strongest simple/uniform blend plus sequential value; gate stability by date/session/coverage, uncertainty and effective sample. Reject learned gate if uniform performs equivalently within frozen margin.
10. **Ablation/fallback/resources.** Each expert/family, gate features, static versus dynamic, uncertainty and missing masks. Unvalidated missing pattern uses designated simple available model or abstention. Class B inference target combined tabular stack<10ms, profiled.

## G02 — Rich volatility and excursion ensembles

1. **Purpose/sources.** Integrate GK/YZ/RV/HAR/jumps/IV/VX/events as an ensemble research problem; explicit user ambition, C06/C09–19, TECH-01–05.
2. **Inputs.** Common-horizon variance or excursion distributions, units/observation process, forecast age and data masks from each specialist. Daily/session/minute targets remain distinct.
3. **Definition.** Two named acyclic ports: G02.V mixes compatible primitive C09–18/23/24 variance forecasts and can feed C06/C19; G02.PATH runs after C06/C03/C19 to mix compatible joint U/D/first-passage distributions and feeds L/G04/05. Compare linear proper-loss stacking, distributional mixtures and context-conditioned gates. No G02.PATH feedback into its current producers. A variance feature may enter an excursion model but is never directly averaged with point quantiles; C15 maps implied information to physical targets first.
4. **Output.** G02.V: forward variance distribution. G02.PATH: joint excursion/path distribution. Each carries calibration, horizon, contribution/disagreement and port identity; only the declared downstream consumers can use it.
5. **Dependencies.** G02.V uses primitive C09–18/23/24, F11, frozen G03.apply and G09.MASK; G02.PATH adds C06/C03/C19 after those complete. G09.SELECT remains downstream. Correlated upstream options information is reported.
6. **Comparisons.** Seasonal range/C13 single expert, uniform/static blend, linear regularized and softmax/nonlinear gate. Out-of-sample residual covariance informs diversity diagnostics, not assumed independence.
7. **Training.** OOF chronological predictions, train-only inverse transformations/normalization, same-date grouping; calibrate tails with uncertainty and effective sample. Separate target horizons to avoid leakage/mismatched scale.
8. **Tests.** Variance versus SD units, annualized IV versus intraday variance, mixed horizon, quantile crossing, no IV, joint U/D coherence, shared-error shock and holiday remainder.
9. **Acceptance.** QLIKE/CRPS/pinball/coverage plus better reach/width/risk and net/day. Better variance error without decision benefit is recorded as predictive-only, not production value.
10. **Ablation/fallback/resources.** Every estimator/input group and gate, physical-IV mapping, joint versus independent excursions. Fall back calibrated seasonal/HAR model. Class B/C reuse expert outputs; no fresh surface fits in gate.

## G03 — Forecast calibration and uncertainty service

1. **Purpose/sources.** Make probabilities usable and comparable; CRL-17, TECH-09, source unverified hit-rate tables.
2. **Inputs.** Time-honest predictions/labels after maturity, target/horizon/asset/coverage identifiers and sample weights. Offline calibration versions; scheduled mature-label monitoring.
3. **Definition.** Binary: logistic `sigmoid(a+b logit(p))`, temperature and isotonic alternatives; multiclass temperature/vector calibration; quantile monotonicity and held-out coverage correction. Calibrate both experts and final mixtures where needed on distinct chronological prediction sets. Produce block-resampled parameter/coverage uncertainty and reliability curves; do not equate predictive interval with parameter certainty or claim iid conformal guarantees under financial drift.
4. **Output.** Calibrated Forecast, calibrator fit interval/version, reliability/support diagnostics and abstention domain. Exact deterministic measurements do not receive invented probability calibration.
5. **Dependencies.** Offline G03.fit uses V01/02/F11 chronological predictions from named producers; online G03.apply is a pure transform with frozen parameters and no current consumer-feedback dependency. It may be applied at expert and mixture stages in the compiled graph. Online monitoring consumes labels only after maturity.
6. **Comparisons.** Identity/no calibration, constant/shrunken event rate, logistic/temperature, isotonic and conditional calibration. Complex local calibration requires enough independent dates and cannot be selected on outer test.
7. **Training.** Preserve deployment prevalence; correct training resampling, include rejected/no-trade candidates, group dates and censor properly. Separate held-out calibration from tuning/test; no full-history labels in live calibrator.
8. **Tests.** Reweighted class prior, all-same prediction, rare tail, probability0/1 stability, horizon mismatch, selected-trades-only bias, monotonicity and future labels entering update.
9. **Acceptance.** Proper score, calibration intercept/slope, reliability/interval coverage with dependence-aware bands; margin/support chosen in development. No arbitrary ECE threshold substitutes for conditional reliability.
10. **Ablation/fallback/resources.** Identity versus each calibrator, pooled versus conditional, window/decay. Sparse cohort shrinks to pooled calibration or unavailable; class B low training/inference cost.

## G04 — Level reach and first-passage expert

1. **Purpose/sources.** Separate existing level from achievable opportunity; JSS failures, SKY decoy/gatekeepers, C19/L source families.
2. **Inputs.** Complete L18 candidate set, current receiver price, object frozen band/distance/age, C19/G02 remaining distribution, C/O/X context and boundary. Pre-touch decision cuts; current-inside object labelled separately.
3. **Definition.** Estimate `P(first contact <=h | I_t)` and competing first-contact/time distribution among candidate regions, including no contact and gap-over. Compare empirical distance/volatility hazard, survival model and joint path simulation from calibrated excursions. Competing nearer/deeper events preserve dependence; separate marginal reach probabilities do not define independent opportunities.
4. **Output.** Reach probability/CDF, arrival-time and possible arrival-state distribution, gap/censor flag, horizon and uncertainty. No reached-only training denominator masquerading as unconditional reach.
5. **Dependencies.** L18/C19/G02/G03/F11; G05 arrival/path, G06–08 and P target room.
6. **Comparisons.** Distance/seasonal volatility threshold; logistic/discrete-time hazard; boosted survival or calibrated path model. Dense candidate-grid and nearest-level rules are comparators.
7. **Training.** All formed candidates/no-touch cases, same-date/object episodes and horizon-aware censoring; OOF forecasts. Current band frozen at prediction, not revised toward future price.
8. **Tests.** Near versus deeper level, gap past both, overlapping bands, target beyond boundary, no-touch day, current-inside band and variable width matched controls.
9. **Acceptance.** Brier/log score, cumulative-incidence/time calibration and selection utility; density/distance/width/time/regime placebos and dependence-aware uncertainty.
10. **Ablation/fallback/resources.** Distance-only, Context, options, band width and arrival-state modeling. Fall back empirical seasonal reach or no prediction. Class B per object; vectorized active-set scoring.

## G05 — Conditional departure, continuation and runner-quality experts

1. **Purpose/sources.** Separate touch from useful future movement and preserve multiple level roles; all source setups, DRF-U01/07, C/L originate trades.
2. **Inputs.** Candidate/object features and C/O/X state at **the forecast cut**; for later contact forecasts, observed contact-prefix evidence only. Fine Response R is an optional additional input family.
3. **Definition.** Estimate ordered favorable/adverse barrier outcome, partial retrace versus sustained runner, reversal/continuation/traversal and time-to-resolution. Pre-touch conditional `P(Y | I_t,reach by h)` uses features at t and labels from the same reached subset/population; it cannot import actual future arrival features. Alternative integrates an arrival-state distribution from G04. Post-touch predictions are separate target/cut versions. Tie/unfinished outcomes explicit; barriers/horizons frozen before outcome.
4. **Output.** Calibrated conditional path distribution/quantiles, excursions and remaining-payoff features, with target/version and uncertainty. It forecasts future behavior; it is not mandatory Response pattern recognition.
5. **Dependencies.** G04/G03/L/C/O/X/F11; G06–08/P management and later R value comparisons.
6. **Comparisons.** Source conditional hit/hold rules, shrunken frequency/logistic competing-risk model, boosted quantile/survival and compact temporal model. Separate pre-touch and post-confirmation information budgets.
7. **Training.** All reached eligible candidates for conditional target plus unconditional reach population, date/object grouping, no post-touch feature leakage into pre-touch model. OOF upstreams; natural prevalence.
8. **Tests.** Touch no reversal, partial reaction then stop, extension continues, favorable/adverse barriers same bar, runner after shallow retrace, late confirmation loses room and no Response evidence.
9. **Acceptance.** Proper path/tail/time calibration and economic value after actual entry costs; composition with G04 reproduces unconditional event frequencies on the same population.
10. **Ablation/fallback/resources.** Local geometry, Context, flow/options, ordered path versus max excursion, Response optional and delay. Fall back calibrated conditional-frequency model. Class B/E sparse event windows.

## G06 — Executable action-value and cost model

1. **Purpose/sources.** Convert predictions into one-mini economic choices; user objective, source execution/confirmation weaknesses, TECH-11 counterfactual limits.
2. **Inputs.** Candidate side/entry/stop/target/horizon, G04/05 path, P05/06 fill/adverse-selection model, fees/latency, current account/position and boundary. Each feasible action at decision time.
3. **Definition.** Estimate net-value distribution for the complete specified action+subsequent exit policy: sum over fill/non-fill and path scenarios of actual-contract gross P&L minus all costs. Non-fill has zero trade P&L plus any explicit order cost; its missed opportunity is compared through G07, not counted twice as a fictitious cash loss. Fill probability and adverse markout are conditioned jointly where dependent. Compare expected net, lower confidence/scenario bound and tail-risk constrained value; quantities are only0/±1.
4. **Output.** `VALUE` distribution, expected net, lower/scenario bound, loss/tail probability, cost decomposition, fill uncertainty and infeasible reason. Replay label is simulated value, not observed causal counterfactual.
5. **Dependencies.** G04/05, enumerated P02 entry/exit plans, frozen P05/06 fill/cost predictors, C19/F11, and pre-decision P01/07/08/09 position/account state. It does not consume the action it is about to select. G07/08 consume values; P risk independently rechecks/reserves after selection.
6. **Comparisons.** Fixed source RR/expected-value rule; empirical outcome/cost table and linear/GAM value; distributional boosted model or calibrated scenario aggregation. A1:1 RR can be positive/negative depending probabilities/costs.
7. **Training.** Common action grid and OOF upstreams, natural candidate population, all fees/non-fills; no profit-only labels. Residual cost calibration comes from held-out telemetry when available; uncertainty otherwise stressed.
8. **Tests.** Good hit rate/negative net, passive no-fill, stop gap, spread1 versus several ticks, confirmation delay, one-mini forbidden partial exit and correlated fill/adverse selection.
9. **Acceptance.** Value calibration and complete sequential net/day/account survival under conservative scenarios; reject apparent edge dependent on optimistic fill or unobserved queue priority.
10. **Ablation/fallback/resources.** Each cost/fill/path model, expected versus conservative value, price-only baseline. Unbounded critical cost/position uncertainty blocks action. Class B/D scenario replay, vectorized few feasible plans per object.

## G07 — Value of waiting, deeper levels and additional information

1. **Purpose/sources.** Solve nearer-now versus deeper-later/confirmation/abstention; explicit user selection requirement, SKY gatekeeper/decoy, CRL dense-level failures.
2. **Inputs.** Complete decision set and G06 action values, G04 arrival/path dependencies, current position/risk/time, possible future observation events and boundary. Every decision cut.
3. **Algorithm.** Baseline compare immediate net value to zero/nearest-next rule. Challenger finite-horizon event decision tree or fitted value iteration `Q(s,a)=E[r+V(s')]` for actions enter-now, place passive, wait-for-deeper, wait-for-simple/Response evidence, cancel and remain flat. Intraday undiscounted reward with time/boundary constraints; no future oracle candidate selection. Waiting branches may see no touch, invalidation, changed context or worsened price; model their transitions and consumed time/risk. Sequential replay re-computes choices from each actual prefix.
4. **Output.** Comparable Q/value distributions, chosen wait trigger/deadline/cancel conditions, opportunity-cost diagnostics and uncertainty. Counterfactual alternatives remain model-based where fills/market impact unobserved.
5. **Dependencies.** G04–06/P state/C19/L17/18; G08 final selector and P01 state machine.
6. **Comparisons.** Act if positive conservative value, fixed nearest/deeper/confirmation rules, finite event tree, regularized fitted Q or model-based planning. Offline RL is not assumed superior; doubly robust evaluation unavailable without defensible action support/logs.
7. **Training.** Sequential same-date trajectories and OOF forecasts, bounded action/state set, inner-fold planning depth/penalties. Full-day perfect foresight is an unattainable diagnostic upper bound only.
8. **Tests.** Deeper never reached, nearer trade blocks later winner, waiting reveals failure, source event expires, passive order pending at boundary, same-time competing levels and loss-budget state changes.
9. **Acceptance.** Paired sequential net/risk improvement over simple act-now and wait rules; policy support/model-error stress; no-go if value depends on impossible future observation or oracle fill.
10. **Ablation/fallback/resources.** No waiting value, no deeper option, no information update, planning horizon and transition model. Fall back predeclared simple conservative policy. Class B/D small event/action tree first, larger planning only after evidence.

## G08 — Candidate ranking and constrained action selection

1. **Purpose/sources.** Choose among many competing objects without unanimity or hindsight; user core ambition, DRF-U03/10/11, CRL-19.
2. **Inputs.** L18 complete feasible set, G06/07 values/uncertainty, G09 applicability, current P position/account and optional R updates. Event/decision cadence.
3. **Definition.** Baseline select highest eligible positive conservative net value after risk; compare pointwise expected-value, pairwise/listwise ranking and permutation-invariant set policy. Include flat/wait/cancel as explicit actions and correlated-evidence groups. Learned rank score must map to calibrated value/decision threshold; ranking accuracy alone does not establish profitability. Final independent P risk veto is always applied; no forced trade count or daily profit recovery action.
4. **Output.** Full ranking, selected action/plan, uncertainty/alternative value gap and reason for every rejection. Risk vetoed candidate remains logged.
5. **Dependencies.** L18/G03–07/09/P; source-only and Context-originated candidates eligible. R absence cannot globally block C/L action.
6. **Comparisons.** Nearest, largest-node, simple confluence-count and regularized tabular value baseline; listwise/set/graph policy. Same candidate population/data/compute for each comparison.
7. **Training.** OOF upstreams, within-date decision sets kept together, natural no-action frequency, no hindsight top-k labels based solely on eventual HOD/LOD. Search budget/margins frozen before outer tests.
8. **Tests.** Modest near versus strong far, competing long/short, all negative values, duplicate correlated levels, no local node, no Response, risk veto and permutation of candidate order.
9. **Acceptance.** Ranking regret/calibration as diagnostics, complete net/day/loss/account survival as promotion criteria; compare density-matched simpler end-to-end competitor and uncertainty intervals.
10. **Ablation/fallback/resources.** Each source/family, set interactions, confluence, uncertainty and waiting; fallback simple validated positive-value selector or flat. Class B/C active-set vectorization; explicit overflow strategy validated, no silent truncation.

## G09 — Applicability, disagreement and abstention gate

1. **Purpose/sources.** Make failures and scarce support visible without blanket confluence requirements; CRL-17, user granular MoE, O21/DA masks.
2. **Inputs.** Critical validity masks, noncritical expert missingness, forecast dispersion/calibration/support, regime/coverage distance and G06 value uncertainty. Decision cadence.
3. **Algorithm.** G09.MASK applies input-validity/critical-data and previously fitted missing-pattern rules before mixtures, using only as-of measurements and frozen reliability state. G09.SELECT runs after G06/07 on forecast disagreement/value uncertainty and support; compare thresholds, empirical reliability and regularized OOF meta-models. It can limit or reject actions, but cannot feed current value outcomes back into same-cut G01/G02 weights. Disagreement is a measured feature; compare reduced confidence and abstention rather than always veto.
4. **Output.** Available/limited/abstain status, reasons, calibrated uncertainty/applicability and permissible fallback set. Never changes one-mini sizing into fractional micros or broadens stops automatically.
5. **Dependencies.** G09.MASK: F06/C20/O21.quality and frozen support state at each producer stage; never current downstream forecast reliability. G09.SELECT: completed G01/02/G03/G06/07 and optional O21.forecast_reliability. G08/P consume SELECT; independent safety remains separate.
6. **Comparisons.** Always-use-valid model, fixed uncertainty/support threshold, logistic/boosted meta-gate. Measure selective risk-coverage frontier and lost opportunity rather than optimize accuracy by rejecting almost everything.
7. **Training.** All eligible predictions and matured labels including no-trade days, OOF meta-features, separate threshold calibration; freeze acceptable coverage/value tradeoff before outer evaluation.
8. **Tests.** All experts missing, one critical quote missing, unfamiliar coverage pattern, experts confidently disagree, rare event, meta-gate trained only on taken trades and shifted feature distribution.
9. **Acceptance.** Conditional reliability/coverage and sequential economic/risk improvement; abstention must not silently remove eligible days from $2k denominator. Unsupported tail/coverage states labelled honestly.
10. **Ablation/fallback/resources.** Disagreement/support/age/missingness separately, no learned gate and hard-confluence comparison. Fallback simple available-data expert or flat. Class B low latency.

## G10 — Per-expert adaptation, recalibration and retirement policy

1. **Purpose/sources.** Preserve adaptive-expert ideas without arbitrary immortal models or trading-only updates; CRL-09/17, user improvement/monitoring requirement.
2. **Inputs.** Matured prediction errors/calibration/economic attribution for every eligible prediction, model age, drift/coverage state and resource budget. State updates happen per event; parameter changes are separate versioned actions.
3. **Definition.** Compare fixed model, expanding/rolling refit, exponential weighting, scheduled recalibration and drift-triggered review in prequential simulation. Candidate initial schedules weekly/monthly calibration and monthly/quarterly refits are an experiment grid, not hard facts. Each expert can have its own tested schedule. Retirement requires a registered inferiority/unsupported-data condition with uncertainty; retain rollback artifact. Frozen future evaluation uses the exact adaptation policy declared at its start, not discretionary rescue changes.
4. **Output.** Proposed model/calibration version transition, evidence/fit interval, effective time, rollback and retirement reason. No autonomous live replacement authorized by this plan.
5. **Dependencies.** V03–06/F11/G03/C20; all experts/gates and deployment promotion. Gate/upstream updates must preserve compatible training and calibration versions.
6. **Comparisons.** Frozen baseline, simple scheduled refit, bounded adaptive/online updates and change-point policy. Price-state response is immediate even when model parameters stay fixed.
7. **Training.** Only matured past labels, including untraded/rejected candidates; no losing-day deletion or freeze of learning on no-trade days. Repeated adaptation choices count as trials; full policy evaluated chronologically.
8. **Tests.** Drift with no trades, late OI labels, gate incompatible with updated expert, calibration collapse, rollback, repeated false alarms and held-out rescue tuning.
9. **Acceptance.** Prequential proper scores/coverage and sequential net/risk stability versus frozen policy, with update cost/false-retirement/lost-opportunity diagnostics. No prescribed expert decay half-life without evidence.
10. **Ablation/fallback/resources.** State-only versus parameter updates, schedule/decay, per-expert versus shared refit and retirement rules. Fall back prior validated version or abstain. Class B/C batch cost bounded/quoted before larger jobs; no hot-path retraining.
