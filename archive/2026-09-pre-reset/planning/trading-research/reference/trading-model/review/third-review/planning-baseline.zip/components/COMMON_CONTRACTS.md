# Binding contracts for every component

These clauses are incorporated into every ten-part component specification. A card supplies its local definitions and deviations; it cannot silently waive causality, units, quality, label or risk contracts. IDs designate independently testable services/experts, not necessarily separate operating-system processes. Parameterized asset/horizon variants receive child IDs in the model registry and their own metrics. All thresholds below described as initial grids or engineering budgets are **proposed starting choices**, not empirical findings.

## CC-01 — Time, replay and availability

Store `event_at`, `received_at`, `published_at`, `known_at`, `computed_at`, `valid_from`, `valid_until`, `source_version` and `clock_uncertainty_ns` as distinct fields when applicable. Missing receipt time stays missing. `known_at` is the earliest defensible availability to the actual strategy: receipt/publication plus processing when observed, otherwise an explicitly tagged latency assumption. A bar's open timestamp does not make its final high/low/close known at the open. A same-time batch is processed in a stable source order only where that order is supported; otherwise declare tie/interval uncertainty and stress admissible orderings.

Derived `known_at` is no earlier than every required input's known_at and completion/confirmation time, plus computation. Publication may refer to an older position/observation date. Revisions create new immutable versions: they do not rewrite the historic decision view. Historical arrival profiles and research replay assumptions are separate; no `max(event,receipt)` shortcut substitutes for resolving clock domains. Time-to-live is a property of the consuming decision horizon and source; age and coverage travel with values even when still permitted.

**Invariant:** remove every observation/version available only after decision time `t`, replay the prefix, and require identical feature/object/forecast/action hashes at `t` (or numerically bounded deterministic tolerance declared before the test). This applies to profiles, confirmed swings, OI reports, macro revisions, adaptive windows, cross-asset mappings, scalers, model weights and universe construction. Restart from a checkpoint plus the same suffix must match uninterrupted replay. Future invalidation must not erase a prior candidate or its rejected decision record.

## CC-02 — Units, keys and universes

Use integer price ticks for outright trade/order prices; retain exact source price scaling and decimal strike/cash prices. Never round a cross-asset mapped location without retaining pre-rounded center/width and mapping error. Contracts, shares, USD premium, futures USD P&L, log return, variance, volatility, delta-equivalent shares/contracts and gamma contribution to option delta-equivalent-dollar change per 1% Greek-coordinate move (with opposite hypothetical offsetting-hedge sign) are different units. Per-option Greek units and contract multiplier are mandatory. IV is stored as an annualized fraction; display percentages never enter arithmetic without conversion. Expiry is a timestamp/calendar convention, not just a date.

Keys include provider/venue, instrument ID, raw symbol, canonical underlying, contract/expiry/right/strike/exercise/settlement, definition validity and corporate-action version. Outright options and spreads are different instruments. For equities, preserve raw and adjustment factors known as of each time; never use today's adjusted historical absolute price for an old option strike join. Futures signals can use a documented continuous-return series; fills and absolute locations use the actual contract, with roll/reset/translation rules recorded.

Use a predeclared `CoverageMask(asset,chain,expiry,moneyness,field,time)` with observed, stale, missing, ineligible, estimated and invalid states. Absence is not zero. Training and reporting stratify by coverage cohort. Learned imputation is fitted only on training data and includes mask/age features; no imputation is permitted for critical executable BBO, position or risk state. Asset membership must be known at the historical time; today's surviving constituent list is not a historical universe.

## CC-03 — Common messages

| Schema | Required payload beyond CC-01/02 |
|---|---|
| `CanonicalEvent` | immutable event ID, instrument key, type/action/side, source payload, normalized units, quality flags, correction linkage, source file/row or live sequence provenance |
| `Measurement` | component/definition/version, asset/anchor/window, value or vector, units, sample count/covered duration, age, quality/missingness, reset reason; no learned confidence attached to exact arithmetic |
| `MarketObject` | object ID, parent IDs, generator/parameter version, source and execution coordinate, center/lower/upper, anchor start/end/confirmation, formation price state, side-neutral geometry, role candidates, creation/revision/expiry/invalidation events, age, touches, map uncertainty, source provenance |
| `Forecast` | target ID, asset/object/action scope, decision timestamp, horizon end, calibrated distribution/quantiles/probabilities, uncertainty type, model/fold/calibrator version, expert availability, applicability mask, reason for abstention, upstream prediction IDs |
| `Opportunity` | decision-set ID, object/version and source-event IDs, candidate side, feasible entry/stop/target plans, reach/path/fill/payoff estimates, estimated all-in costs, risk consumption, alternative wait actions, coverage and uncertainty |
| `Decision` | complete candidate IDs and scores, selected action and rejected reasons, pre-action position/account state, parameter/model hashes, order intent/expiry, risk approval/veto, local processing/dispatch timestamps |
| `OrderEvent` | client/broker IDs, request/ack/cancel/fill/reject/reconcile type, quantity, side, price, fees, venue timestamps, receipt, previous state, idempotency key |
| `Outcome` | forecast/opportunity/decision reference, label definition/version, maturity time, censor/ambiguous-tie flags, predicted/observed target, simulated/actual fill status, costs, horizon and sequential-account linkage |

An object can be both a possible reversal and continuation reference. Its geometry does not encode a guaranteed direction. A source event can produce a receiver opportunity without a mapped receiver-level touch. Different generators can retain distinct identities at the same price, linked by a correlated-evidence group; merging cannot manufacture independent votes.

## CC-04 — Label dictionary

Every label starts **after the decision's information cut**. Price-event labels use a declared observation process (trade, midpoint or executable bid/ask). Economic labels use actual contract prices and a declared fill/latency model. Do not mix them in one accuracy number.

- `PATH(h)` records signed return, upper/lower excursions, first passage times to frozen barriers, barrier order, time spent/volume inside regions, horizon-end location and no-event/censor status. Initial research horizons: 5, 15, 30, 60 minutes, named session remainder and required-day remainder. These are separate registered targets, not pooled observations. Very short flow experiments additionally use 1, 5, 15, 30 seconds only in data cohorts whose timing supports them.
- `REACH(object,h)` is first entry of the observation process into the object's **decision-time frozen band** by horizon. Crossing a gap past it is not an executable touch. Store gap-cross as a separate event. Revising the band creates a new forecast target; old labels remain tied to old versions.
- `DEPART(object,side,h,a,b)` is the ordered outcome after first observable contact: favorable barrier `a` versus adverse barrier `b`, unresolved, gap/ordering ambiguous, and excursions at maturity. Barriers use frozen tick/volatility-scaled choices determined at the prediction time. This forecasts future price behavior, not the optional Response module's pattern class.
- `TRAVERSE` records entering/exiting a value area or range, first opposing-edge passage and competing failure/reclaim, never eventual-day hindsight. Unordered both-edges-touched is a different target from lower-then-upper.
- `VALUE(action,h)` is full-position net P&L/utility after the candidate action, including fill or non-fill and explicit subsequent policy, conditional on the observable decision state. A candidate's counterfactual value in replay is a **simulation label**, not a measured causal effect of our order.
- `OI_NEXT(contract,position_date)` becomes observable only on the next legitimate report/revision. Store the exact horizon/report version. Separate continuing contracts from expiries, exercised/adjusted contracts and missing publications; do not label every disappeared 0DTE contract as an accurately predicted intraday liquidation.

For joint labels, estimate the joint distribution or conditional factorization consistently. Multiplying an unconditional reach probability by a response probability trained on a different selected sample is forbidden. If both barriers occur inside one coarse bar and order is unknown, label ambiguous or evaluate pessimistic/optimistic bounds; never pick the favorable order.

## CC-05 — Sampling, normalization and learning

Fit on chronological training data. Group correlated assets/options/contracts and all overlapping candidates from the same trading date in the same partition. Purge training examples whose feature/label/availability span overlaps a validation/test interval; embargo is derived from horizon and state carryover, not copied as a fixed percentage. Training-history features may legitimately look backward across a boundary; future labels and scalers may not. Long OI/swing/profile lifetimes are tracked by explicit interval intersections.

Keep a uniform clock-time/background sample plus all registered candidate/source events; weights recover the intended decision population. Do not train only on taken trades or successful touches. Store negative/no-touch/censored outcomes. Control repeated retests through object/date grouping and sample weights. Class imbalance: compare natural-prior likelihood training with training-only weights/downsampling; if reweighted, recalibrate to deployment prevalence on untouched calibration data. Missingness is an input and an analysis cohort, not a reason to invent data.

Normalize return/flow/range features by preceding asset/session scale, robust training-fold statistics or causal expanding estimates, with a declared zero-scale fallback. Never use full-day volume/range to normalize an earlier decision. Learned upstream forecasts consumed by another learned component must be **out of fold and time honest**. Construct inner chronological predictions, fit downstream only on those predictions, and regenerate them for each outer fold. Final fitted upstream models may serve the outer test but may not retroactively replace their in-sample training outputs in the downstream training set.

Each learned family compares (a) an interpretable rule/constant or seasonal-frequency baseline, (b) a simple statistical model matched to the target, and (c) justified nonlinear/sequence/set candidates. Compare common information and compute/search budgets; separate an information improvement from a model-class improvement. Deterministic components have no learned arithmetic replacement requirement: their statistical/learned comparisons concern forecasting or anomaly detection downstream, and are explicitly marked not applicable where they would change semantics.

## CC-06 — Mixtures and disagreement

For a target `Y_h`, eligible experts produce distributions `p_e(Y_h|I_t)`. A convex mixture is `p(Y_h|I_t)=sum_e w_e(t)p_e`, `w_e>=0`, `sum_e w_e=1` over available experts. Compare uniform, fixed validation-weighted, regularized logistic/softmax gating and a shallow nonlinear gate. Gates receive as-of context, coverage, expert age and out-of-fold predictions; never realized future errors. A measurement vector, GEX dollar level and return forecast are not averaged as if they share units.

Calibrate expert distributions and the combined distribution on separate chronological calibration predictions. For binary outcomes compare logistic and isotonic calibrators; for multiclass compare temperature/vector calibration with sample-complexity control; for quantiles use held-out coverage correction. Record conditional calibration and dependence violations; distribution shift voids automatic coverage guarantees. Common-target disagreement is mixture spread plus between-expert dispersion; interpret it as diagnostic uncertainty, not automatic alpha.

Missing expert weights are masked and renormalized only if this missingness pattern was validated; otherwise use the designated simple available-data model or abstain. If every expert is missing, return no forecast. Gate collapse is diagnosed through occupancy, effective expert count, correlated residuals and ablations; equal utilization is not forced when evidence favors one expert. Diverse feature sets/horizons/structural assumptions are designed explicitly, and experts remain independently scored. Gating cannot override independent risk.

## CC-07 — Common verification matrix

Each component owns `T-<ID>-UNIT`, `-PROP`, `-SYN`, `-INT`, and, when learned/actionable, `-PRED`, `-ECON`, `-ABL`. Cards name local fixtures and metrics. The validation plan supplies cross-cutting tests `T-TIME`, `T-CAUSAL`, `T-DATA`, `T-UNIVERSE`, `T-FILL`, `T-ACCOUNT`, `T-OOF`, `T-PLACEBO`, `T-SEARCH`, `T-SHADOW` and `T-RESTART`. Deterministic algebra/semantic invariants have zero unexplained failures; numeric tolerances come from units/solver accuracy, not a tolerance chosen to make a failed test pass.

Prediction metrics: proper log/Brier score for categorical events; pinball/CRPS and interval coverage for distributions; QLIKE plus robust error for variance; MAE/Poisson or negative-binomial deviance for counts; concordance/calibrated cumulative incidence for time-to-event; conditional residual diagnostics for every family. An improvement is judged on paired same-date predictions with dependence-aware intervals, not independent touch t-tests. Sample sufficiency comes from learning curves, effective date/block counts, interval width and a predeclared economically relevant effect. Rare cohorts are pooled/shrunk or marked unsupported, not awarded arbitrary confidence at `n=30`.

Economic acceptance requires the complete sequential one-mini replay, cost stress and risk constraints; a local score alone is insufficient. Material gain thresholds and non-inferiority margins are selected in development from economic requirements/measurement error and frozen before outer/future evaluation. No component gets an invented proven hit-rate threshold. A risk/quality service may be retained for an invariant or measured risk reduction even if it lowers mean P&L; the tradeoff must be explicit.

## CC-08 — Ablation, monitoring and fallback

Every component has a no-component or simpler-component challenger, a source/input-family ablation, a definition/parameter sensitivity and relevant time/order/coverage placebo. Monitor schema/units, missingness, feature/target distributions, calibration, applicability, latency, stale outputs, prediction drift and downstream value attribution. Drift tests alert; they do not authorize autonomous model replacement. Predeclared calibration/refit/rollback policies are evaluated prequentially on all matured eligible labels, including no-trade days. Immediate online state updates are distinct from retraining model parameters.

Fallback preserves semantics: a stale quote is unavailable, a missing OI estimate is uncertain, an absent profile is not a zero-volume shelf, an uncertain gate yields the validated simple model or abstention. A critical order/position mismatch triggers reconciliation and independent risk action. No fallback increases position size, widens a stop to recover losses or fabricates hidden liquidity.

## CC-09 — Resource/latency classes

These are planning budgets to measure on the inspected ~17.85 CPU/~77.3 GiB/A4000-16 GiB pod, not observed benchmarks. Cards declare a class and a scaling driver; stage one profiles actual throughput before any large run.

| Class | Expected work | Initial budget and scaling |
|---|---|---|
| A | Deterministic streaming state | O(1) per event or O(log active objects); bounded RAM per instrument/anchor; aim microseconds–submillisecond/event in compiled hot path; aggregate publication 100 ms–1 min according to target |
| B | Tabular/statistical specialist | CPU training minutes–hours on event/decision tables; 1–8 GiB typical trial; batch inference target <10 ms per decision for the combined tabular stack; exact budget profiled |
| C | Surface/set/graph specialist | CPU surface solves or small GPU models; seconds–hours calibration/training to start, 4–14 GiB GPU budget; initial boards at 1 min cadence, target <1 s end-to-end; record actual completion delay |
| D | Raw replay/validation | I/O dominated; stream one instrument/day with RAM cap 48 GiB and bounded sorted spill; storage grows with retained events and trials; never multiply 37B rows by every feature configuration in memory |
| E | Deferred detailed Response sequence | Candidate-centered event buffers and compact statistical/sequence learners; actual latency budget determined by measured post-confirmation opportunity; no low-latency profitability assumption |

For storage estimation use measured `rows/day × retained bytes/row × days × versions` plus checkpoints and model artifacts, report compressed and uncompressed. For a larger machine, report required CPU/GPU hours and a quoted hourly rate when procurement is considered; this plan does not invent current cloud prices or approve paid work. Train-free deterministic outputs and shared causal features are cached by hash to prevent duplicate work across experts.

The [computation schedule](COMPUTATION_SCHEDULE.md) is a binding elaboration of these contracts: component cards list both upstream services and downstream consumers for readability, while the schedule specifies directional runtime ports. A model registry must compile those ports to an acyclic graph before fitting or replay.

## CC-10 — Meaning of completion and deferral

A specification card is complete when its inputs/outputs/algorithm/alternatives/test/decision contract is implementable; its empirical parameter choice may remain a registered experiment. A component is implemented only after code and applicable tests exist. A component is validated only after the prescribed held-out evidence exists. These three statuses are different.

Detailed Response development is deferred by the user's current sequencing preference. The R-series cards preserve each mechanism and specify the measurable sequence, prerequisites, competing models and later tests. No source mechanism is silently dropped; no promise is made that all require production deployment. Fine response-trigger annotation and model tuning follow Context/Location baseline validation. Requirements depending on unavailable hidden depth/participant identity remain unidentifiable unless new data actually supply the missing observation.
