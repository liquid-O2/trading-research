# Options: surfaces, uncertain holdings, flow and actionable nodes

Binding [common contracts](COMMON_CONTRACTS.md), DA-05–09 and TECH-05/13–16 apply. Preserve NDX/NDXP/QQQ, SPX/SPXW/SPY, NQ/ES futures-options and other actually acquired option families separately. The design extends to all supported assets/expiries; missing data create masks and acquisition dependencies, not invented complete boards. Exposure and flow measures are hypotheses about market pressure, not observed dealer inventory.

## O01 — Chain assembly, eligibility and coverage accounting

1. **Purpose/sources.** Establish the actual chain before computing a board; DRF-U03/04, IMG, SKY029/053/063/064, DA-05–08.
2. **Inputs.** F02 definitions/listings, F07 quotes/OI/trades/underlying joins, exercise/settlement and publication state. Per chain/expiry/right/strike, 1-minute snapshots and event-driven updates.
3. **Definition.** Construct a sparse contract table with observed/stale/estimated/missing status per field. Deduplicate near/broad acquisitions by exact contract/time/version. Separate listing universe, quoted universe, traded-so-far universe and OI-reported universe. Compute quote-count and known-OI coverage by DTE/moneyness and masks for unsupported wings/tenors; no use of full-day traded universe before close.
4. **Output.** `ChainSnapshot`, complete contract IDs, source rows/ages, coverage vector and declared denominator. No direction or learned confidence yet; insufficient chain fields block only dependent calculations.
5. **Dependencies.** F02/F04/F07; O02–21 and X joint boards use the same snapshot version.
6. **Comparisons.** Exact sparse union baseline; fixed common-contract intersection for fair comparisons; trained masked imputation as a separate O04 variant. Never fill absent options with zero exposure by default.
7. **Rules.** Point-in-time listing certification separate from acquired daily list. Split adjusted contracts and spreads; session/0DTE eligibility uses exact settlement time.
8. **Tests.** Duplicate quote acquisitions, no near monthly expiry, truncated wings, later-listed contract, full-day active list, OI after snapshot, removed expiry toggle and same strike AM/PM series.
9. **Acceptance.** Reproduce all three-date six-chain audit numerators/denominators; zero duplicate mass/forward joins; every board carries coverage and comparison cohort.
10. **Ablation/fallback/resources.** Intersection versus supported union, observed-only versus estimated wings, fixed versus changing universe. Coverage failure returns masked partial board. Class C sparse minute table; storage measured per contract snapshot.

## O02 — Option price validation and IV inversion

1. **Purpose/sources.** Obtain defensible volatility inputs to Greek/level models; DRF-U04, TECH-05, DA stale/crossed quotes and missing futures-options BBO.
2. **Inputs.** O01 bid/ask/sizes/age, underlying spot or specific future, forward/discount/dividend estimates with known_at, strike, exact expiry/exercise/settlement and multiplier. Minute/available quote cadence.
3. **Algorithm.** Validate no-arbitrage price bounds under the appropriate contract model; solve IV by bracketed root finding with explicit convergence tolerance in option-price units. Use European forward/Black formulation for eligible European contracts and a discrete-dividend American tree/finite-difference benchmark for American ETF/futures-option classes as defined by registry; do not assume all CME options are European. Compare mid, bid and ask IV to produce an interval; stale/wide/one-sided prices remain flagged. Intrinsic-only/near-expiry cases may have no identifiable IV.
4. **Output.** IV estimate/interval, price residual, solver/model version, model assumptions, quality/age and failure reason. A trade-implied IV without contemporaneous BBO is a separate noisy estimate, not a live fair quote.
5. **Dependencies.** F02/07/O01 and X02.bootstrap underlying/forward estimates where needed. Outputs feed O04/O05/C15. Raw-quote parity in X02.bootstrap cannot depend on this IV solution; intraday cash-price proxy uncertainty is propagated.
6. **Comparisons.** Vendor IV where legitimately available, direct mid inversion, bid/ask interval and smoothed-price solver; simple carry-forward IV versus learned surface estimates. Solver arithmetic is deterministic, learned adjustment is separately evaluated.
7. **Rules.** Curves/dividends/underlying mapping as-of; today's revised rates not used historically. Calibrate quote-quality selection in development, freeze; failed inversion remains missing.
8. **Tests.** Put-call parity European fixture, American early-exercise/dividend, zero DTE minutes, zero bid, crossed BBO, extreme wing, underlying lag, percent/fraction and wrong multiplier/settlement.
9. **Acceptance.** Price round-trip within predeclared tick-scaled tolerance, bounds/convergence checks, bid≤mid≤ask IV where monotonic and valid; downstream uncertainty sensitive to price/underlying assumptions.
10. **Ablation/fallback/resources.** Mid versus bid/ask bounds, valuation model, quote age and carry-forward. Unidentifiable IV blocks point Greek claim; bounded/scenario exposure may remain. Class C vectorized CPU solves, reuse per-minute warm starts.

## O03 — Options trade-sign uncertainty

1. **Purpose/sources.** Preserve signed flow without equating ask prints with certain intent; Flowseeker/SKY032/060/074, TECH-15, DA-04.
2. **Inputs.** Trade price/size/condition/venue/sequence and strictly prior valid BBO/age; native trade time and receipt where known. OPRA near-expiry trade-quote coverage; futures reported aggressor separately.
3. **Definition.** On a valid strictly positive spread, at/above ask→buy and at/below bid→sell; inside-spread→unknown or separate midpoint/tick-rule challenger. Locked quotes cannot satisfy both side rules: use reported reliable aggressor or a separately validated classifier, otherwise unknown. Reject/rematch future/stale/crossed pairs and preserve unknown mass. A probabilistic sign model requires reliable labelled overlap. Aggressor sign identifies neither opening/closing, customer/dealer nor multi-leg intent.
4. **Output.** Sign estimate/probability/interval, method, known/reliable flag, quote provenance and uncertainty. No fabricated ground truth for unlabelled OPRA trades.
5. **Dependencies.** F05/07/O01 raw trade/quote quality; IV inversion is not a prerequisite for a valid trade sign. Optional O02 price-bound diagnostics must not suppress all flow when IV is unidentifiable. O15/16/O07 consume sign uncertainty.
6. **Comparisons.** Quote rule, tick rule, conservative unknown; logistic/boosted classifier only with valid labels; sensitivity scenarios otherwise. Futures exchange sign supplies a calibration test within its own market, not automatic OPRA accuracy.
7. **Training.** Labelled subset bias and venue/session generalization assessed; natural sign prevalence retained. Future quote/next IV excluded even if vendor enriched row contains it.
8. **Tests.** Three audited future quote pairs, four-hour stale quote, midpoint, locked market, spread transaction, unknown condition, conflicting tick/quote signs and repeated same-size prints.
9. **Acceptance.** Exact causal pairing; reliability where labels exist, uncertainty sensitivity where they do not. Flow claims must survive conservative unknown and sign-error perturbations.
10. **Ablation/fallback/resources.** Hard versus probabilistic signs, quote age, midpoint exclusion, venue/condition. Unsupported sign stays unknown. Class A/B native trade processing; no guaranteed sign accuracy.

## O04 — Arbitrage-aware volatility surface and uncertainty

1. **Purpose/sources.** Model full supported strike/expiry structure, including sparse wings; user rich chains, DRF-U04, TECH-05, SKY064 limitations.
2. **Inputs.** O02 IV/price intervals and residuals, log-forward moneyness `k=ln(K/F)`, remaining expiry time, rights/settlement, O01 masks. Separate economic contract classes; minute snapshots and causal warm starts.
3. **Definition.** Fit total variance `w(k,T)=σ²T` using spread/quality-weighted robust loss in option-price or IV space. Compare piecewise/spline interpolation with constrained SVI/SSVI across compatible European expiries; enforce nonnegative variance, nonnegative implied butterfly density and calendar consistency under stated assumptions. American products use their valuation-consistent price constraints, not blindly European parity. Mark interpolation/extrapolation domain; fit observed prices, do not hide missing wings behind smooth confidence.
4. **Output.** Surface parameters/grid, bid/ask-consistent uncertainty scenarios, coverage/domain flags, pricing residuals, constraint violations and known_at after solver completion. No unsupported exact wing value.
5. **Dependencies.** O01/02/F11; O05 Greeks, O09 exposures, C15 and X joint models.
6. **Comparisons.** Nearest valid IV/flat smile, constrained interpolation, SVI/SSVI, regularized multi-expiry surface, masked neural residual model only after simpler fits. Model choice depends on held-out quote prediction and downstream utility.
7. **Training.** Parameters fit current known snapshot; structural hyperparameters/smoothing train-only. Do not calibrate morning surface with later quotes. Chronological held-out-contract/time residuals; no random same-snapshot leakage into temporal tests.
8. **Tests.** Nonconvex price smile, calendar crossing, sparse wing, different settlement time, zero expiry, stale underlying, changed universe, solver local minimum and bid/ask uncertainty propagation.
9. **Acceptance.** No unexplained hard constraint violation in eligible domain; held-out price error versus spreads, stability and calibrated uncertainty; gamma/node economic effect tested separately.
10. **Ablation/fallback/resources.** Flat versus smile/term, observed-only versus inferred wings, constraints, quality weights and prior smoothing. Fall back to validated simpler/local surface or no valuation. Class C, warm-start vectorized fits; profile <1s board goal.

## O05 — Greeks and unit-consistent sensitivities

1. **Purpose/sources.** Separate delta/gamma/vega/vanna/charm/volga and their actual meaning; DRF-U04, GXF, SKY GEX/VEX, garbled 'voltage/vol revised' observations.
2. **Inputs.** O04 surface/scenarios, O02 pricing model, F02 multiplier/underlying/expiry and current S/F/time. Per contract, minute or material underlying move.
3. **Definition.** Compute delta `∂V/∂S`, gamma `∂²V/∂S²`, vega `∂V/∂σ`, vanna `∂delta/∂σ`, charm `∂delta/∂calendar time` and volga `∂²V/∂σ²`, with fixed convention for σ in fraction and time in years. Distinguish sticky-strike, sticky-delta and fitted-surface total derivative scenarios. Charm versus derivative in remaining time has opposite sign convention. Validate analytic/automatic derivatives with finite differences where applicable.
4. **Output.** Greeks per underlying unit and per contract, scenario/version, finite-difference residual and uncertainty; no combining unlike units. 'VEX' vendor formula unknown unless documented; use explicitly named own vanna-exposure measure.
5. **Dependencies.** O02/04/F02; O09/10/16/17, C15 and L options levels.
6. **Comparisons.** Standard contract-model Greeks; finite-difference and surface-aware Greeks; learned residual only with held-out pricing justification. More derivative orders are retained only if stable and useful.
7. **Rules.** Annualization/model conventions immutable per version; near-expiry blowups handled by numerical/quote uncertainty, not arbitrary clipping that creates desired nodes. Training-only stabilization parameters.
8. **Tests.** Delta monotonicity in valid simple fixture, gamma/vega sign for long vanilla, vanna unit factor100, charm time sign, American exercise boundary, finite differences and near-expiry stability.
9. **Acceptance.** Unit/price derivative identities within declared solver tolerance; scenario stability quantified; downstream ablation determines whether each Greek adds value.
10. **Ablation/fallback/resources.** Delta/gamma only versus added Greeks, surface convention and uncertain wings. Unstable sensitivities masked; class C vectorization/shared surface, minute outputs with measured completion time.

## O06 — Reported OI state and next-report label service

1. **Purpose/sources.** Keep OI knowledge distinct from position date; DRF-U02/06, TECH-13, DA-07/08, SKY069/070.
2. **Inputs.** Contract OI reports/statistics, position date, event/receipt/publication/revision, definitions and expiry/corporate-action state. Update only on report arrival; snapshots intraday use last known report with age.
3. **Definition.** Maintain last legitimate published OI and complete report lineage; no assumed zero for absent row. Match successive comparable reports by contract and position interval, accounting for expiry/adjustment. `ΔOI_next=OI_next−OI_current` is a matured aggregate label; tag incomplete acquisition and report revisions. Use previous trading report, not blindly previous calendar day.
4. **Output.** As-of OI state/age/known fraction, next-report labels/maturity/censor flags and revision differences. Not intraday dealer positioning.
5. **Dependencies.** F02/04/07/O01; O07/08/09 and V01 labels. Report values never join to earlier decisions via their position date.
6. **Comparisons.** Last-known OI baseline; delayed/same-day report scenarios; revision-aware versus naïve-date diagnostic. No learned publication decoder; forecast is O07.
7. **Rules.** Labels use frozen report-version policy (first report primary, revisions diagnostic); missing/expired not automatically negative OI. Data embargo follows label publication horizon.
8. **Tests.** After-15UTC OI rows, Friday→Monday, holiday, zero/no report distinction, next-UTC-date receipt, revised OI, expired 0DTE and adjusted contract.
9. **Acceptance.** Exact availability/contract matching and label maturity; next-report coverage/censoring by expiry cohort; no future OI in any feature hash.
10. **Ablation/fallback/resources.** First versus revised report, report lag sensitivity, exclude uncertain contracts. Use last valid OI with age/scenarios or unavailable. Class A sparse daily state; low compute.

## O07 — Aggregate next-reported-OI forecast experts

1. **Purpose/sources.** Develop the user's OI calibration ambition beyond a volume proxy; DRF-U01/02/06, IMG dynamic dots, CEX options ideas.
2. **Inputs.** O06 prior OI/history, cumulative and recent observed volume, O03 sign uncertainty, O15/16 flow, price/IV/skew changes, expiry/time/moneyness, venue/condition and coverage. Predict at predeclared intraday cuts and material flow events, contract and strike/expiry aggregate scopes separately.
3. **Definition.** Target next comparable reported OI or ΔOI. Compare persistence; constrained linear/count models; zero-inflated/negative-binomial or distributional boosting; hierarchical contract→strike→expiry model; compact sequence/set model. Include total volume separately from signed volume. Enforce nonnegative predicted OI, but do not enforce a trade-only ΔOI bound when exercise/adjustment/report corrections can violate it. Produce coherent aggregates by summing posterior samples or reconciled hierarchical distributions.
4. **Output.** Next-report OI predictive distribution, quantiles/probability of material net increase/decrease, maturity/censor flags and coverage. It predicts a future aggregate report, **not actual OI at the current intraday instant**.
5. **Dependencies.** O01/03/06/15/16/F11; O08 uncertain state scenarios and O09 boards. Downstream uses OOF forecasts; next-day true OI only evaluates them.
6. **Baselines/candidates.** Persistence, prior OI plus fixed fraction of volume, linear/hierarchical count model, boosted/sequence candidates. Separate overall OI accuracy from the error on small/new/0DTE contracts and large nodes.
7. **Training.** Same-date/expiry-family grouping, publication-aware purging, prefix samples weighted by day/contract; retain unknown signs/coverage. Non-expiring, newly listed, adjusted and expiry contracts have separate heads/cohorts. Avoid treating every minute prefix as an independent endpoint label.
8. **Tests.** Equal signed flow/different gross volume, closing versus opening ambiguity, no trade/change in reported OI, missing report, large new contract, early prefix versus full-day leakage and coherent aggregate uncertainty.
9. **Acceptance.** MAE/deviance/CRPS/interval coverage and improvement over persistence on held-out dates; additionally improve node/reaction and economic tests versus static/volume boards. Better endpoint prediction alone is insufficient.
10. **Ablation/fallback/resources.** Remove signs, IV, history, hierarchy, late flow, estimated wings; sensitivity to report revisions. Fall back to persistence+wide interval. Class B/C contract snapshots; sample cuts control repeated-label volume.

## O08 — Intraday aggregate-holdings scenario updater

1. **Purpose/sources.** Separate a useful uncertain intraday exposure estimate from unidentifiable true holdings; user dynamic gamma ambition, DRF-U06, SKY flow/OI cautions.
2. **Inputs.** Prior reported OI O06, observed cumulative volume/flow and O07 next-report forecasts, contract exercise/expiry/adjustment state and coverage. Intraday event/minute updates.
3. **Algorithm.** Baseline freeze holdings. Challenger scenarios allocate observed trades to opening/closing/unchanged net stock with latent fractions and uncertainty; in a no-exercise/no-adjustment synthetic setting, aggregate OI lies within `max(0,OIprev−volume)` and `OIprev+volume`. Actual scenarios add exercise/adjustment/report uncertainty. State-space/particle filtering can be trained against later endpoint reports, but many paths yield the same endpoint: retain a posterior family, no asserted true path. Filtering uses prefix only; smoothing is research label analysis, never live input.
4. **Output.** Current aggregate-OI **scenario distribution/identification interval**, method assumptions and next-report consistency diagnostics. Dealer sign/ownership remains separately unknown.
5. **Dependencies.** O06/07/15/16; O09 scenario exposures and O21 confidence. O07 terminal forecast is not renamed current OI without this explicit model.
6. **Comparisons.** Frozen OI, proportional volume heuristic, constrained latent update/filter, learned conditional opening-fraction model only with uncertainty. Direct price/flow-to-reaction models bypass latent holdings as an important challenger.
7. **Training.** Endpoint supervision alone cannot validate intraday truth; report identifiability and sensitivity to priors. Tune on inner dates, evaluate terminal and downstream predictions separately; 0DTE has explicit expiry model or abstention.
8. **Tests.** Identical endpoint/different intraday paths, all opening/all closing/no-change flow, exercise without trade, contract expiry, future report accidentally entering filter and nonnegative stock.
9. **Acceptance.** Scenario consistency/calibration where observable; downstream improvement robust across plausible latent assumptions. Reject any claim of precise dealer/current inventory or gains dependent on one unverifiable allocation.
10. **Ablation/fallback/resources.** Latent updater off, prior strength, endpoint forecast, flow fractions and 0DTE removal. Fall back frozen OI with uncertainty. Class B/C small particle/scenario sets per active contract/aggregate, minute cadence.

## O09 — Exposure scenarios and concentration boards

1. **Purpose/sources.** Preserve many strikes/expiries and signed/magnitude boards; IMG, DRF-U03/05, GXF, SKY Heatseeker/core, user options Location requirement.
2. **Inputs.** O05 Greeks, O06/O08 holdings scenarios, multiplier, underlying and O01 coverage. Separate chain/expiry/right, 1-minute and material price/IV/flow updates.
3. **Definition.** Let n be signed assumed option holdings, M the multiplier, and u the Greek coordinate (spot S or the named underlying future F). Gamma contribution to option delta-equivalent-dollar change for a +1% coordinate move is `n M gamma u² .01`, valued at the initial u; an offsetting delta-neutral hedge adjustment has the opposite sign. This excludes the existing delta’s mark-to-market term `n M delta du`; it is not total change in `n M delta u` and is not observed dealer hedge flow. Retain unsigned long-option concentration and explicit call-plus/put-minus, opposite-sign and flow-conditioned holdings scenarios. Delta dollars are `n M delta u`; option vega P&L is `n M vega Δσ`; vanna contribution to delta-equivalent dollars is `n M u vanna Δσ`, with opposite offsetting hedge sign. Charm uses explicit elapsed-time convention and the same distinction. Never sum unlike units into an unexplained strength score.
4. **Output.** Strike×expiry×chain exposure channels, net/gross concentration, scenario intervals, coverage and computation time; sign conventions in schema. Aggregation across assets requires explicit mapping/unit normalization in X.
5. **Dependencies.** O01/05/06/08; O10–14/17 and L options generators, C15 and X board forecasts.
6. **Comparisons.** Static prior-OI gamma board, mechanically repriced static holdings, volume proxy, OI-forecast scenarios and direct flow channels. Compare gross and signed information separately.
7. **Rules.** Freeze holdings/sign conventions per trial; use OOF learned updates. Contract universe changes recorded, unquoted wings flagged estimated. No proprietary GEX/VEX formula replication claim.
8. **Tests.** Multiplier factor, IV unit, call/put long gamma both positive, 1% versus one-point move, expiry removal, sign reversal, absent wing and synthetic known-portfolio hedge sensitivity.
9. **Acceptance.** Unit/aggregation/finite-difference identities; scenario uncertainty and chain coverage; incremental node/forecast/economic value over static and price-only baselines.
10. **Ablation/fallback/resources.** Net versus gross, individual Greeks/expiries/chains, holdings/sign scenario, observed-only domain. If sign uncertain, preserve magnitude and scenario family. Class C vectorized sparse boards, cached minute snapshots.

## O10 — Mechanical-versus-flow exposure-change decomposition

1. **Purpose/sources.** Avoid interpreting every thickening dot as new positioning; user screenshot, SKY core/visual cases, DRF-U05, DA varying universe.
2. **Inputs.** Two consecutive comparable O09 boards, O04/05 inputs, O06/08 holdings and O01 universe/coverage snapshots. Update at each version change.
3. **Algorithm.** Revalue previous holdings/universe under new underlying price, IV surface and time; separately change holdings assumptions and true contract universe. Report residual/interactions. Baseline fixed order decomposition; challenger average over factor orders/Shapley allocation or symmetric two-sided attribution. Coverage loss is a data effect, not an economic expiry/unwind. Compute fixed-intersection board change alongside full-union change.
4. **Output.** Price, IV, time, holdings-assumption, expiry/listing, coverage and interaction contributions with units/scenario intervals; sum reconciles to total change under chosen decomposition.
5. **Dependencies.** O01/04/05/08/09; O12 dynamics, O13 patterns, X joint and L node updates.
6. **Comparisons.** Raw exposure change; frozen-holdings repricing; ordered versus symmetric decomposition; learned residual predicts future path only after explaining its inputs, not labelled 'dealer flow'.
7. **Rules.** Attribution convention frozen/versioned. Surface/holdings uncertainty propagated; no future chain/next-IV data. Interactions are not silently assigned to holdings.
8. **Tests.** Price-only move, IV-only shock, time decay, same data/changed expiry selector, missing quote wing, actual expiry, offsetting factors and additive reconciliation.
9. **Acceptance.** Exact total-change reconciliation and synthetic factor recovery; incremental prediction over raw change robust to order/scenario choice. No causal proof of holdings from unexplained residual.
10. **Ablation/fallback/resources.** Remove decomposition, fixed intersection, factor channels and scenario spread; monitor residual/coverage spikes. Fall back raw labelled change plus uncertainty. Class C revaluation cost proportional to contracts×scenarios, cap factor permutations by measured budget.

## O11 — Node extraction, width and stable identity

1. **Purpose/sources.** Preserve small/non-max nodes, migration and changing dot strength as numeric objects; IMG, DRF-U03/05/07, SKY087/085, JTR competing levels.
2. **Inputs.** O09 strike/expiry channels and O10 decomposition, underlying coordinates, coverage and surface uncertainty. Every supported chain, per-expiry and declared aggregate views, minute cadence.
3. **Definition.** Detect local concentration maxima/minima, adjacent-strike clusters and exposure-weighted centers; keep sign/magnitude separate. Compare no smoothing, fixed kernel and train-fixed adaptive smoothing. Width reflects strike spacing, cluster spread, surface/holdings and mapping uncertainty, not dot pixel size. Match nodes across snapshots by strike/expiry membership overlap plus bounded center distance; split/merge/birth/death are explicit versions. Do not retain only kings or require top-percentile nodes.
4. **Output.** `MarketObject` with member contracts, center/band, magnitude/sign channels, uncertainty, birth/confirmation, parent relationships and provisional status. Display radius/opacity is not an input.
5. **Dependencies.** O01/09/10/F10; O12/13/17, X mapping and L options roles.
6. **Comparisons.** Individual strikes/top absolute concentrations, deterministic adjacent clusters, KDE/online density clustering, learned proposal/width model with matched density and uncertainty. Cluster identity is deterministic conditional on a registered method.
7. **Training.** Cluster metric/thresholds chosen only in inner folds; use positive/negative channels separately, not signed density. Log all qualifying nodes and rejected proposals; late universe changes cannot rewrite old membership.
8. **Tests.** Small node reaction, two nearby nodes merging, same magnitude/opposite sign, changing expiry selection, display clamp, one-strike shift, missing wing and birth after contact.
9. **Acceptance.** Stable identity/provenance and no future generation; calibrated width/coverage; node usefulness beyond distance/density-matched random levels and raw strike grid.
10. **Ablation/fallback/resources.** Small nodes off, aggregate versus per-expiry, smoothing, width and identity history; fall back individual valid strike nodes. Class C sparse local clustering; bounded active-set index.

## O12 — Node persistence, migration and thickening/thinning experts

1. **Purpose/sources.** Quantify temporal board observations; IMG, DRF-U05, SKY006/019/020/022 and visual supplements.
2. **Inputs.** O11 node histories, O10 factor decomposition, elapsed time/expiry, price distance and observed touch state. Per node/chain/expiry, minute and contact-event updates.
3. **Definition.** Measure magnitude/gross-share changes, center/width velocity, persistence, source-contract turnover and rank changes. Separate raw growth, holdings-scenario growth and mechanical revaluation. Forecast node survival/migration, reach and post-contact return/continuation. 'Original node grows after delivery, price may revisit' is a conditional hypothesis with a new decision time after observed growth, not a pre-touch hindsight feature.
4. **Output.** Temporal measurements and common-target survival/path distributions, uncertainty and split/merge lineage. Node disappearance due missing data is not decay/unwind.
5. **Dependencies.** O10/11/F10; O13 patterns, X board interactions, L dynamic location lifecycle and G selection.
6. **Comparisons.** Persistence/static magnitude, linear slopes/empirical hazards, survival/GAM/boosted models and compact temporal encoder. Compare information of rank/absolute magnitude versus normalized share.
7. **Training.** Per-node/date dependence, censor expiry/coverage loss distinctly; OOF upstream learned holdings. Historical UI after-date OI/IV excluded.
8. **Tests.** Price-only growth, actual input flow, node rank changed by expiry toggle, merge/split, post-touch growth with delayed knowledge, far static node and quoted universe loss.
9. **Acceptance.** Survival/time/path calibration; incremental actionable value over static node distance/magnitude with matched coverage and latency.
10. **Ablation/fallback/resources.** Remove history, decomposition, rank or touch state; shuffled temporal order. Fall back to static current valid node. Class B/C sparse histories, minute inference.

## O13 — Exposure topology and source pattern grammar

1. **Purpose/sources.** Preserve Heatseeker mechanisms without copying universal bans; SKY006/008–023, DRF joint boards and screenshot.
2. **Inputs.** Complete current O11 node set, O12 dynamics, O09 sign/magnitude scenarios, price/expiry/time and C19 reach budget. Per chain/expiry and declared aggregates.
3. **Definition.** Encode distance-ordered concentrations, largest 'king' magnitude regardless of sign, intervening 'gatekeepers', opposing clusters, air pockets in exposure, dominance ratio, node spacing and migration. Named hypotheses: whipsaw between opposing nodes; rainbow-road mixed concentrations; squeeze/rolling ceiling-floor; weakening support/rug-pull; distant/implausible decoy; vanna/expiry stairstep topping; delivery/revisit and news/OPEX failure. Exposure air pocket is not measured order-book liquidity. Midrange/no-confluence remains eligible; source rules are features/benchmarks, not hard exclusions.
4. **Output.** Interpretable pattern vector plus calibrated joint-path/transition forecasts and uncertainty. Intent labels such as deceptive dealer node are not asserted.
5. **Dependencies.** O09–12/C17 produce topology measurement independently of C19. Its optional pattern-forecast port runs after C19; O14.base can consume only the measurement port, not this current pattern forecast. O22/X/G consume later forecasts.
6. **Comparisons.** Faithful named-rule detectors, continuous topology features with logistic/GAM, set/graph temporal classifier. Rule names need not be the best learned representation; retain provenance even if merged.
7. **Training.** Pattern thresholds/nodes learned in inner folds; include failed/no-pattern boards and all candidate opportunities, not selected screenshots. Same-date grouping and coverage masks mandatory.
8. **Tests.** Intervening small node, largest unreachable node, mixed signs at same strike, no local receiver node, late pin versus early drive, event invalidation and coverage-induced disappearing support.
9. **Acceptance.** Pattern detection semantic fixtures; future-path calibration and incremental utility versus simple node distance/density. No source 66/33 or 1:1-RR blanket rule as truth.
10. **Ablation/fallback/resources.** Named patterns versus continuous features, signs versus magnitude, expiry mix and dynamics; matched randomized topology. Fall back to individual node features. Class B/C sparse topology graph.

## O14 — Within-chain strike-by-expiry pattern experts

1. **Purpose/sources.** Preserve full chain structure beyond three aggregated boards; user central ambition, DRF-U03/04, SKY029 aggregate limitations, TECH-08.
2. **Inputs.** O01 sparse contract/strike tensors, O04 surface, O09 exposures, O12 histories, O15/16 flow and coverage/age. Coordinates log-forward moneyness, remaining calendar/trading time, right, chain and settlement class. Minute histories.
3. **Algorithm.** Compare fixed tenor/moneyness summaries; per-expiry experts plus calibrated fusion; permutation-invariant Deep Sets `rho(sum phi(contract features))` with coordinates/masks; attention/set or graph messages along strike/expiry edges and causal temporal encoder. Preserve absolute strike/location information alongside normalized coordinates. Heads forecast future `PATH`, node `REACH/DEPART` and optional OI endpoint; auxiliary losses cannot leak labels into inference.
4. **Output.** Common-target calibrated distributions, expiry/strike contributions, uncertainty and coverage applicability. Missing contracts are masked; reordering records must not change a prediction.
5. **Dependencies.** O01/04/09/12/15/16/F11; X06 joint asset model and O22/L options candidate forecasts.
6. **Comparisons.** Transparent scalar summaries, regularized tabular model, per-expiry ensemble, set/graph/temporal candidates. Match input domain/search budget; do not prefer a transformer simply for novelty.
7. **Training.** Same-date and overlapping-expiry labels grouped/purged; train-only coordinate scaling, coverage dropout matching real patterns, OOF upstream estimates. Sample fewer decision cuts rather than duplicate every contract-minute endpoint as independent.
8. **Tests.** Permutation invariance, missing expiry, one concentrated strike, identical aggregate GEX/different expiry topology, chain type mismatch, future temporal token and padding-mask leakage.
9. **Acceptance.** Proper scores/calibration and incremental node/portfolio utility over summary baselines; report sample/compute learning curves and leave-expiry/coverage cohorts.
10. **Ablation/fallback/resources.** Strike structure, expiry structure, time, flow, learned OI and surface channels separately; randomized compatible edges. Fall back to per-expiry/tabular expert. Class C, initial small model within 14GiB GPU; larger scale only after evidence.

## O15 — Signed options contracts and premium-flow ledger

1. **Purpose/sources.** Preserve Flowseeker print/contract/chain distinctions and ordinary options CVD; SKY032/033/034/043/055/060/074, user CVD variants.
2. **Inputs.** Eligible option trades, O03 sign distribution, contract multiplier and option price, chain/expiry/right/venue/condition. Native updates, minute and session cumulative views.
3. **Definition.** Contract flow `sum s_i q_i`; premium flow `sum s_i q_i price_i M_i`, with buy/sell/unknown gross totals. Maintain calls/puts separately. Gross call premium minus gross put premium is a different sentiment proxy from aggressor-signed premium and must have a different field name. Print feed, contract aggregate, strike/expiry/chain aggregation and ranked subset are separate views. Top-N feed cannot reconstruct full flow without an audited complete aggregate.
4. **Output.** Contract-unit and USD-unit CVD/increments, gross/unknown totals, sign-error bounds and period reset. Store both signed expected value and conservative scenario interval.
5. **Dependencies.** F05/O01/O03/F03; O07/08/14/18/20, C/X forecasts. No adding contract counts to premium totals.
6. **Comparisons.** Gross volume/call-put totals; quote-rule signed flow; probabilistic sign-weighted flow and robust summary model. Learned predictive interpretation separate from ledger arithmetic.
7. **Rules.** Intraday cumulative totals stop at known_at; historical daily ranks, later OI and next IV excluded. Preserve unselected trade/contract counts and scope rather than trusting only notable prints.
8. **Tests.** Buy put versus sell put, same contracts/different premium, multiplier100 versus futures20/50, midnight/reset, missing sign, duplicate print, top500 truncation and mixed-leg package.
9. **Acceptance.** Mass/notional conservation and full-scope reconciliation; future-path/calibration/economic contribution versus gross-flow baseline under sign uncertainty.
10. **Ablation/fallback/resources.** Contracts versus premium, calls/puts, uncertain-sign exclusion, large-only versus all flow. Unknown stays separate. Class A/B native event accumulation and sparse contract state.

## O16 — Delta-, gamma-, vanna- and charm-weighted flow/CVD

1. **Purpose/sources.** Preserve the user's gamma-related CVD and exposure-weighted flow variants as distinct measurements; user clarification, CEX/DRF, SKY flow enrichment.
2. **Inputs.** O15 trade records/sign uncertainty and O05 Greek snapshots satisfying BOTH `valuation_event_at ≤ trade.event_at` and `valuation_known_at ≤ trade.known_at`, with multiplier, exact expiry and X02.bootstrap mapping. Freeze the selected weight once that trade becomes available; missing eligible valuations remain missing or use a separately tagged causal fallback.
3. **Definition.** Signed source-price sensitivity is `D_u=sum s q M delta`, in USD per unit of the declared source coordinate u; for equity options this can be expressed as equivalent shares, while futures-option equivalents additionally divide by the underlying point value. Delta dollars are D_u times u. Gamma-weighted option flow is `sum s q M gamma u² .01` per +1% coordinate move; this is traded-option sensitivity, with opposite sign for a hypothetical offsetting hedge adjustment, not observed hedging. Vanna flow is `sum s q M u vanna` per unit IV change; charm declares its time unit. Preserve event-frozen weights; later-event valuation available at trade receipt is separately arrival-repriced, and subsequent revaluation is separately decomposed. With `b=∂F_receiver/∂u`, mini-equivalent delta is `D_u/(b*point_value_receiver)`; gamma-driven change for +1% u at fixed b is `sum s q M gamma u .01/(b*point_value_receiver)`. Mapping-Jacobian changes are separate terms. Call/put long gamma are positive; call-minus-put is a holdings heuristic. Fractional exposure features do not change the one-mini execution set.
4. **Output.** Separate unit-tagged weighted-flow/CVD channels, cumulative/bar OHLC where event ordering supports them, uncertainty/scenarios and Greek age. Minute totals alone cannot recover intraminute extrema.
5. **Dependencies.** O03/05/15, X02/F04; O07/14/18, C18/X forecasts and R optional flow divergence.
6. **Comparisons.** Contracts/premium only, fixed delta/gamma approximations, event-Greek weighted flow, repriced series and learned common-target model. No automatic assumption gamma-CVD outperforms traded CVD.
7. **Training.** Greek/surface/mapping models OOF where learned; normalize by preceding same-chain sensitivity scale, preserve physical units. Unstable 0DTE Greek weights get masks/intervals, not concealed clipping.
8. **Tests.** Buy call/buy put gamma sign, sell option, IV unit100×, delta-equivalent mapping units, Greek known after trade, same final weighted flow/different path and frozen versus repriced cumulative series.
9. **Acceptance.** Dimensional/finite-difference checks and causal Greek joins; incremental forward/economic value for **each** channel with sign/Greek uncertainty stress.
10. **Ablation/fallback/resources.** Each Greek/cohort/expiry, event-frozen versus repriced, gross versus signed. Fall back O15 if Greeks unavailable. Class A/C reuse minute Greeks, event accumulators; no duplicate surface solves per print.

## O17 — Exposure-weighted strike center and bands

1. **Purpose/sources.** Preserve Atlas GEX VWAP's actual mechanism and improve it transparently; SKY087, user relevant-toolset request.
2. **Inputs.** O09/O11 exposure at each strike, chosen expiry universe and current board availability. Recompute each valid minute snapshot; no traded volume input unless explicitly a different variant.
3. **Definition.** `mu=sum |G_k|K_k/sum |G_k|`; upper/lower centers weight strikes above/below **mu**, not spot. Source filtering retains all nodes or nodes at least a fixed fraction of largest magnitude (e.g.50% of king, not 50th percentile). Compare signed-channel separate centers and uncertainty-weighted centers. Optional source envelope tracks center/band extrema during an opening calibration window (default15min, minimum8 valid minutes in documented behavior); frozen and session-widening versions distinct and known only after sufficient observations.
4. **Output.** Exposure center/upper/lower objects, denominator, expiry/filter version and uncertainty; missing board creates gap, not invisible carry. Explicitly not traded-price VWAP and not a confidence interval.
5. **Dependencies.** O09/F10; X related-price mappings, L options-center candidates and C15/X pattern features.
6. **Comparisons.** Source magnitude center; unfiltered/all-expiry versus per-expiry; robust trimmed/quantile center and learned conditional role. Conventional VWAP M07 remains a separate comparator.
7. **Rules.** Freeze filter/envelope choice in training; default expiry changes are new objects. Mapping other boards into SPX/NQ coordinates uses X02, not an unpublished Trinity formula.
8. **Tests.** Center differs from spot, threshold fraction versus percentile, no nodes on one side, zero denominator, opening minimum sample, expiry toggle and missing minute.
9. **Acceptance.** Formula/source semantics exact; causal envelope timing; incremental reach/departure utility versus price VWAP/strike mean and matched placebo centers.
10. **Ablation/fallback/resources.** King filter, envelope, expiry aggregation, signed channels and mapping. Missing side remains unavailable. Class A/C linear in strikes, reuse board.

## O18 — Flow breadth, concentration and OI-relative activity experts

1. **Purpose/sources.** Preserve richer Flowseeker summaries without denominator confusion; SKY036/039/041/045/046/049/051/055/066/069/070.
2. **Inputs.** Complete as-of O15/16 ledger, O06 known OI, contract/strike/expiry universe, prior same-time volume history and coverage. Minute and session cumulative views.
3. **Definition.** Compute separate trade-count share, contract-volume share, premium share, active-contract breadth, call/put and aggressor ratios, concentration/entropy, volume-to-known-OI, same-time relative activity and net reported OI change. Zero denominator produces undefined/infinite-category with flags, never arbitrary0/999 treated numeric. Vendor full-day extrapolated sweep totals and future historical-baseline dates are not causal current measures.
4. **Output.** Named unit/denominator-explicit features and target-specific future-path forecasts; no assertion high volume/OI proves opening or informed intent.
5. **Dependencies.** O06/15/16/F07; O07/14/X/G. Baseline volume curves use preceding comparable sessions only.
6. **Comparisons.** Raw volume and put-call count ratios; shrinkage-normalized relative flow/logistic model; boosted interactions/set features. Vendor composites retained as disclosed benchmark formulas only, including their scope limitations.
7. **Training.** Prior-window reference distributions, min-support shrinkage, unknown/missing OI separate from zero; same-date grouping. Full-day ranks/percentiles unavailable earlier.
8. **Tests.** No puts/no sells/zero OI, many tiny prints versus few large, same premium/different contracts, day boundary, missing denominator universe and elapsed-time normalization.
9. **Acceptance.** Denominator identities and causal baselines; incremental path/calibration/economic information beyond O15 raw flow on common scope.
10. **Ablation/fallback/resources.** Breadth/concentration/OI ratio/relative time separately, all versus top flow. Undefined ratios remain masked. Class A/B sparse counters and small tabular models.

## O19 — Futures-options-specific information experts

1. **Purpose/sources.** Include NQ/ES options rather than limiting options to OPRA boards; original pull/inventory, user full universe, DA-08.
2. **Inputs.** Native DBN option definitions, trades, statistics/OI/settlement and minute OHLCV, underlying future and receipt times. January2020–September2026 archive scope; no acquired options BBO assumed.
3. **Algorithm.** Resolve outright/UDS/leg structure first. Use reported trade aggressor for flow; published OI/settlement only after receipt. Build separate settlement-implied and trade-implied volatility estimates with uncertainty, never a fabricated continuous quoted surface. Construct exposure/flow/strike-expiry summaries through O04–18 only where valuation is supported. UDS package information remains separate unless legs/ratios are decoded.
4. **Output.** Futures-options contextual/node forecasts, field coverage and valuation-confidence masks, specific underlying-future coordinate. No execution in options is proposed.
5. **Dependencies.** F01/02/04/O01–06/O15/16; X Nasdaq/S&P family fusion and C/L forecasts.
6. **Comparisons.** Futures price-only, OI/settlement-only, trade-flow-only, combined with OPRA chains; linear/boosted/per-expiry set candidates. Distinguish information overlap from unique contribution.
7. **Training.** Receipt-aware labels and actual contract lifetimes; no parsing display strike suffix; no pooled outright/spread price/Greek model. Train/test on matched NQ/ES and options-coverage dates.
8. **Tests.** `NQH0 C0000` strike10000, sentinel multiplier/tick, negative UDS statistic, same sequence multiple stats, stale definition snapshot, no option BBO and settlement ts_ref earlier than publication.
9. **Acceptance.** Instrument/units/availability certification; predictive/economic increment over OPRA-only and futures-only on same opportunity sets. No unsupported IV precision claim.
10. **Ablation/fallback/resources.** Flow/OI/settlement, spreads/outrights, individual expiry families and receipt versus event-only stress. Fall back flow-only if IV unavailable. Class B/C, native streaming and sparse snapshots.

## O20 — Multi-leg, sweep and large-print ambiguity specialist

1. **Purpose/sources.** Preserve Flowseeker filters while avoiding false parent-order identity; SKY032/044/060/074, user options-flow ambition.
2. **Inputs.** Trades with venue/condition, contract/expiry/price/size/time, O03 signs, package IDs/legs only if actually supplied. Native event windows; OPRA and CME mechanisms kept distinct.
3. **Definition.** Baseline condition-based package flags and one-contract/multiple-venue/short-time sweep heuristic; one-second Skylit window is a benchmark. Compare temporal/size/leg-ratio clustering and probabilistic package membership. Do not call repeated size a proven parent order or use later cluster membership at first print. Separate outright flow, suspected package flow and unknown; aggregate package Greeks only when legs/ratios and direction are defensible.
4. **Output.** Observed/suspected package class, confidence/support, membership-known_at, gross/net sensitivity scenarios and incomplete-package flag. No observed dealer/customer identity.
5. **Dependencies.** F02/05/O03/15/16; O07/14/18 and X. Unknown conditions retained for verification, not arbitrarily decoded.
6. **Comparisons.** No package grouping, documented condition flags, deterministic heuristic and probabilistic clustering; learned classifier only with suitable labelled packages/overlap. Scope sensitivity preferred over unsupported labels.
7. **Training.** Cluster windows/thresholds train-only; package completion delays in inference. Include single-leg and coincidental-print controls; avoid whole-day clustering used retroactively.
8. **Tests.** Coincidental same-size prints, genuine known spread, incomplete legs, delayed second venue, full-day sweep count leaking later flow and package sign reversing naive call/put story.
9. **Acceptance.** Precision/recall only where labels exist; otherwise quantified scenario sensitivity and incremental forecast robustness to exclusion of suspected packages.
10. **Ablation/fallback/resources.** Exclude suspected packages, vary causal grouping window, condition-only versus cluster. Unknown remains separate. Class A/B bounded event buffer; no exhaustive combinatorial leg search without measured value.

## O21 — Options uncertainty and applicability propagation

1. **Purpose/sources.** Make uncertainty actionable rather than a generic warning; DRF-U08, all options data findings, SKY display/proprietary limitations.
2. **Inputs.** Quote/underlying age, coverage, IV/surface residuals, OI forecast/scenario spread, sign ambiguity, mapping error and node instability. Every options forecast/object update.
3. **Algorithm.** Propagate a finite joint scenario ensemble through Greeks→exposure→nodes→path forecasts; preserve dependence (same S/IV/holdings scenario across contracts) instead of independent error bars. Compare empirical residual calibration and conservative bounds for unidentifiable inputs. Applicability classifier estimates when a forecast beats its simple baseline on OOF data; it does not learn from same-sample realized P&L at inference.
4. **Output.** Forecast intervals, scenario dispersion, field-specific quality reasons, calibrated reliability and available/limited/unavailable status. A confidence score cannot create missing data.
5. **Dependencies.** O21.quality uses O01–20 measurement/scenario ports and X02.bootstrap, without C19-dependent pattern forecasts or X03–06. O21.forecast_reliability may evaluate completed downstream predictions later, under F11/OOF, and feeds only later G09.SELECT. No downstream reliability output feeds the current upstream forecast it evaluates. L width/P risk can use the appropriate available port.
6. **Comparisons.** Hard validity+age rules, stratified reliability/shrinkage, regularized meta-model; scenario propagation versus single-point estimate. Complexity only if it improves calibration/decision quality.
7. **Training.** OOF errors and held-out chronological calibration; coverage regimes separated from market regimes. Extreme sparse states return wide uncertainty/abstention rather than unsupported extrapolation.
8. **Tests.** Common underlying shock across whole chain, correlated wing errors, missing expiry, stale quote, perfect-looking smooth surface with low coverage and unsupported missing-expert pattern.
9. **Acceptance.** Conditional coverage/reliability and better risk-adjusted selection under realistic perturbations; report unsupported identification rather than claiming statistical calibration solves it.
10. **Ablation/fallback/resources.** Point versus scenario, each uncertainty source, coverage-aware versus blind model. Fall back validated static/observed-only board or no options forecast. Class B/C bounded scenarios, latency profiled with whole board.

## O22 — Options node/path and actionable-role forecast experts

1. **Purpose/sources.** Ensure options improve actionable levels and do not stop at OI/GEX estimation; DRF-U01/03/07–11, IMG, SKY patterns.
2. **Inputs.** O11 nodes, O12 dynamics/O13 topology and pattern forecast/O14.base representation, O15/16 flow, optional O23 settlement-payoff benchmark objects, C19 path/room and X01/02 measurement mapping/age. The first local options forecast excludes current X03–06 fused forecasts. Predict at pre-touch and observed-contact cuts.
3. **Definition.** Separate heads forecast reach, rejection/continuation/traversal, partial retrace versus runner, target room and lifecycle/invalidation hazard, with common CC-04 labels. Compare indirect holdings→exposure→node features to direct chain/flow→future-path models and their mixture. A node may be a target, reversal reference, continuation support or irrelevant given current state. No obligatory matching local node or universal green/red fade rule.
4. **Output.** Calibrated object-specific path distributions and role probabilities; L13/14 convert to opportunities, G compares wait/act. A direct learned location offset is bounded, causal and logged as a new proposal, not the day's hindsight best strike.
5. **Dependencies.** O01–21 and optional O23/C19/X01/02/F11 for O22.local. X03/04 consume the frozen local output, followed by X05 then X06. Optional O22.joint_refined may consume X06 once, without feeding its same-cut ancestors; score it separately. L/G/P consume the registered port; fine Response optional.
6. **Comparisons.** Static strongest/nearest node rule, shrunken conditional touch model, regularized/boosted utility model, set/graph temporal specialist. Simple direct-flow challenger tests whether latent OI complexity is actually necessary.
7. **Training.** All nodes/background/placebos with natural prevalence, same-date grouping, no selected screenshot labels, frozen barriers/horizons and post-contact evidence availability. Distinguish pre-touch forecast from later re-evaluation.
8. **Tests.** Small node wins/largest fails, source SPX reaction before NQ local touch, no QQQ node, gatekeeper intervenes, node decays due data loss, 0DTE expiry, post-confirmation payoff disappears.
9. **Acceptance.** Proper path/reach/calibration plus one-mini sequential utility under matched candidates/density/coverage. Gains robust across sign/OI/surface scenarios and years; OI score alone cannot pass.
10. **Ablation/fallback/resources.** Each chain/expiry/Greek/flow/history/holdings model, direct versus mediated path, local-only versus source event. Fall back calibrated simple supported-node model or abstention. Class B/C sparse per-object scoring, cached shared representation.

## O23 — Per-expiry max-pain settlement-payoff benchmark

1. **Purpose/sources.** Preserve GXF-07’s named max-pain mechanism with an explicit definition; test it against full nodes/round strikes rather than accepting pinning claims or discarding the idea silently.
2. **Inputs.** O06 previously available aggregate OI q_i, F02 strike/right/multiplier/adjusted deliverable, one underlying and exact settlement/expiry class, O01 universe coverage. Recompute on legitimate OI/report/universe revisions; an O08 scenario-based variant is separately named. Never combine AM/PM settlements or different expiries as one terminal price event.
3. **Definition.** For ordinary compatible contracts, `J(x)=sum_calls q_i M_i max(x−K_i,0)+sum_puts q_i M_i max(K_i−x,0)`. Return the complete minimizing set of this convex piecewise-linear terminal intrinsic-payoff function over the instrument’s valid settlement-price domain. Evaluate strike breakpoints and slope changes; a flat minimum is an interval, not an arbitrarily selected strike. Adjusted/nonstandard deliverables need their true payoff function or are excluded with coverage loss. This hypothetical aggregate long-option intrinsic payout is not dealer P&L, observed ownership, a hedge optimum or a force attracting price. American early-exercise history is not modeled by this terminal-only benchmark.
4. **Output.** Minimizer point/interval/unbounded-domain flag, payout curve and minimum, chain/expiry/OI version, coverage/assumption uncertainty and valid-at time. Map through X02 only after retaining the native set. No unique executable level is manufactured from a broad/undefined minimum.
5. **Dependencies.** F02/O01/O06, optionally O08 for a separate scenario variant; L14 may produce benchmark objects and O22/G forecast their reach/path/value. It does not feed IV inversion or require current downstream forecasts.
6. **Comparisons.** Deterministic breakpoint/reference-grid calculation; nearest round strike/strike mean/static node; shrunken frequency or logistic role model and existing O22 learned-role challenger. A learned replacement for the payoff arithmetic is unnecessary.
7. **Training.** Arithmetic has no training. Role/scenario/window parameters use OOF/fold-only rules and common candidates; no future OI or realized settlement to choose a current level. Separate near-expiry, earlier expiry and missing-wing cohorts; unknown coverage stays uncertain.
8. **Tests.** One equal-strike call/put pair; flat minimum interval; calls-only/puts-only unbounded-side minimum; zero OI; multiplier/corporate-action change; mixed-settlement rejection; missing wings shifting minimum; observed spot on either side; next-report leakage. Compare breakpoint solver with independent direct payoff sums.
9. **Acceptance.** Exact payout/minimizer/availability semantics; no empirical promotion without calibrated reach/path and complete net increment over full-node and density/width/distance-matched round-strike baselines. Source caption/image absence is not evidence of the claimed level.
10. **Ablation/fallback/resources.** No max-pain input, per-expiry versus registered scenario, OI age/coverage and mapping uncertainty. No data/no bounded useful minimizer means no dependent candidate. Class A/B, O(n log n) sorted strikes (linear after sorting), shared sparse OI cache; role forecasts reuse O22/G.
