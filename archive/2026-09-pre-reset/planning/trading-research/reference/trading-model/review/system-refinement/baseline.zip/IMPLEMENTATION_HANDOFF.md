# Implementation handoff

Prepared 2026-09-06 after the full planning review and the MBP-1 clarification. Implementation has not started. A new implementation thread in the same project/workspace is recommended as a distinct work outcome; this thread can remain the planning record. The receiving thread must read the files below and verify access rather than assume that every planning message is already in its transcript. Official guidance supports separate chats for distinct outcomes and durable guidance in project files. [Projects and chats](https://learn.chatgpt.com/docs/projects).

## Task and constraints to preserve

Develop and empirically evaluate the complete Context → Location → Response research architecture. Context and Location can originate entries. Build their measurements and neutral execution/risk harness first; detailed Response development comes later, with all its source mechanisms retained.

The primary experiment is one account, flat or one outright NQ/ES mini, preferably NQ; a $2,000 average daily net objective across all eligible days including zero-trade days; a $1,000 daily loss objective; and flat at the required boundary. No account copying, added units, partial exits or micro substitution. Feasibility is unknown. Report trading net and business cash separately until the target accounting basis is resolved.

Use the whole supported information universe. NQ/ES are execution choices, not a limit on Context/Location inputs. Preserve options, volatility, cross-market, range, auction/profile, flow and all other routed hypotheses. MBP-1 is the primary available futures event source; “BBO” means its validated best-quote state unless a sampled-schema comparison is explicitly named. Follow the [market-data source contract](MARKET_DATA_SOURCE_CONTRACT.md), including action/side/flags, timing omissions and provider-normalization rules.

The previous failed workspace archive under `/workspace/archive/` is excluded from inspection/adoption by the user's earlier instruction. Supplied source conversations remain in scope, including earlier assistant proposals as hypotheses rather than established results. Preserve original source/data bytes.

## Reading order and source of truth

1. [README](README.md), [master plan](IMPLEMENTATION_PLAN.md), [requirements](REQUIREMENTS_TRACEABILITY.md), [market-data source contract](MARKET_DATA_SOURCE_CONTRACT.md).
2. [Common contracts](components/COMMON_CONTRACTS.md), [computation schedule](components/COMPUTATION_SCHEDULE.md), [runtime scheduler](components/RUNTIME_SCHEDULER.md).
3. [Data audit and coverage limits](DATA_CAPABILITY_AUDIT.md), [validation plan](VALIDATION_PLAN.md), [quality criteria](MODEL_QUALITY_AND_STOPPING_RULES.md), [ordered backlog](IMPLEMENTATION_BACKLOG.md), [E0 reference](E0_REFERENCE_EXPERIMENT.md).
4. Relevant component cards and [individual experiments](experiments/README.md) for the milestone being built. Read every dependency's contract, not only the leaf model.
5. [Source ledger](SOURCE_REVIEW_LEDGER.md), [source findings](SOURCE_FINDINGS_AND_CONFLICTS.md), [conversation recheck](CONVERSATION_RECHECK.md), [source routes](traceability/SOURCE_TO_DESIGN.md), and original referenced passages for each implemented mechanism.

The third review and this later source contract refine the older baseline where they explicitly correct it. Any new semantic conflict must be recorded and resolved before dependent implementation; do not silently simplify the broader plan or treat a historical proposal as a validated method.

## What is complete, and what is not

| Area | Completed evidence | Work still required |
|---|---|---|
| Supplied-source review | Recorded full review of 39 PDFs/580 pages, five conversations, two standalone indicators, 83 ZIP text/source members and supplied imagery; 712 finding records | Reconcile each implemented formula with its original passage and test its causal corrected variant |
| Design | 153 ten-part component specifications; 191 refinement experiments; eight proposed phases for each of 344 units | Implement, run, compare and diagnose; these are specification counts, not proven models |
| Market archive | 111 dataset directories/80,198 files reconciled; 216 representative Parquet files across all 75 Parquet datasets; 1,046,522 selected rows checked | Intended-partition quality scans, source/version semantics, availability, recovery, identity and common-cohort certification |
| Futures events | Two complete selected hours reconciled between MBP Trade records and standalone trades; additional all-167 NQ/ES MBP footer and 86,016-row five-family field/flag check | Stratified reconciliation, book-state/reference parity, event/flag recovery and native versus exported field contracts |
| Index/ETF options | Three dates × six chain families checked for listing/OI/quote joins and coverage; broader bounded timing/quote checks | Certified point-in-time universes, surface/Greek reference tests, missing-wing treatment, sign/condition rules and full intended-cohort scans |
| Native futures options | 24 selected definition/trade/statistics/bar DBN files, headers and three records each | Complete outright/spread registry, quote limitations, sentinels/ticks/multipliers and publication/revision handling |
| VIX options | Additional three-day feasibility check: 261,970 quote rows, selected OI files and illustrative parity/IV calculations | Historical contract/rate/clock/receipt certification and valid surface/forecast testing; no signed VIX tape was acquired |
| Model/economic validation | 27 finite numerical design examples and document/traceability checks | All model fitting, strategy backtests, account simulations, future shadow trials and profitability evaluation |

These audits have different depths. No exhaustive semantic or row-level certification of every dataset, trading feature or model is complete. VIX was a focused addition prompted by a concrete IV question; it does not stand in for the broader program. Use the family-by-family readiness section in the data audit to prioritize unresolved dependencies.

## Start with B00 and B01

Once implementation is requested, create an isolated research package in the active workspace after checking existing files and applicable repository instructions. Start with typed contracts, provenance, reference readers and tiny deterministic replay fixtures. Build an explicit dataset/field/cohort eligibility ledger across the entire catalog, then certify the minimum NQ/ES event cohorts needed for E0 and the broader supported families independently.

Retain a literal decoder/reference implementation for comparison with optimized readers. For MBP-1, preserve action, reported side, every raw flag and source order; derive trades and BBO without duplication or an MBO-only filter. Resolve the actual gap and snapshot examples already recorded. Missing optional features disable dependent experts only.

Continue through B02 deterministic measurements and source objects, then B03/E0 as the first complete economic benchmark. The E0 decision rule is deliberately small; it is not the final signal universe. Keep a live implementation-status file mapping every component/experiment to unstarted, implemented, verified, evaluated or rejected, with exact evidence. Model families earn inclusion through chronological comparisons and complete-policy value, not their count or reputation.

Existing scripts in `review/` are planning/audit utilities. The proposed `python -m trading_research ...` commands in the backlog do not yet exist. Initial work should use bounded partitions and measured resource costs. Deployment, paid acquisition, trades and messages to others require their own authorization; this handoff does not initiate them.

## Suggested first message for the new thread

> Start implementation of the trading research system in this workspace. Read `/workspace/planning/trading-model/IMPLEMENTATION_HANDOFF.md` and its required documents first. Preserve the full plan and all user constraints. Begin with B00/B01 contracts, MBP-1 event ingestion and cross-dataset eligibility, then the bounded replay and measurement foundations. Keep an implementation/evidence ledger and continue through the authorized research work. Do not treat proposed tests as passed or a model as profitable before evaluation.
